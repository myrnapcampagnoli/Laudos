@echo off
chcp 65001 >nul
echo.
echo  =========================================
echo   Laudos - Medica de Entrelinhas
echo  =========================================
echo.
echo  Abrindo o app no navegador...
echo  Para encerrar: feche esta janela.
echo.

cd /d "%~dp0"

start http://localhost:8765

python -m http.server 8765
IF %ERRORLEVEL% NEQ 0 (
  py -m http.server 8765
  IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ERRO: Python nao encontrado.
    echo  Acesse: https://www.python.org/downloads/
    echo  Marque "Add Python to PATH" na instalacao.
    echo.
    pause
  )
)
